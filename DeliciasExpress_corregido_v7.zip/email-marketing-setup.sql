-- ============================================================
-- SETUP COMPLETO: Email Marketing (Ofertas Relámpago)
-- Proyecto: DeliciasExpress
-- Cómo usar: Dashboard de Supabase -> SQL Editor -> New query
-- -> pega TODO este script y ejecútalo.
-- ANTES: crea tu cuenta en https://resend.com y copia tu API Key.
-- ============================================================

-- 1. Activar la extensión pg_net (permite llamar a la API de Resend desde SQL)
CREATE EXTENSION IF NOT EXISTS pg_net;

-- 2. Tabla de ofertas relámpago (solo si no existe)
CREATE TABLE IF NOT EXISTS public.flash_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  discount_percentage INT NOT NULL CHECK (discount_percentage BETWEEN 1 AND 100),
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ends_at TIMESTAMPTZ NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE public.flash_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Ofertas visibles para todos"
  ON public.flash_offers FOR SELECT
  USING (true);

CREATE POLICY "Admins gestionan ofertas"
  ON public.flash_offers FOR ALL
  USING (public.get_user_role() = 'admin')
  WITH CHECK (public.get_user_role() = 'admin');

-- 3. Guardar el correo en profiles (lo que faltaba en el trigger)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email TEXT;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    NEW.email, -- Guarda el correo del usuario
    'cliente'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Copiar los correos de los clientes que YA se registraron antes
UPDATE public.profiles p
SET email = u.email
FROM auth.users u
WHERE p.id = u.id AND p.email IS NULL;

-- 5. La función que envía los correos (la que llama admin.js)
CREATE OR REPLACE FUNCTION public.send_flash_email(p_offer_id UUID)
RETURNS JSONB
LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_offer   RECORD;
  v_product RECORD;
  v_emails  JSONB;
BEGIN
  SELECT * INTO v_offer FROM public.flash_offers WHERE id = p_offer_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'emails', '[]'::jsonb, 'error', 'Oferta no encontrada');
  END IF;

  SELECT * INTO v_product FROM public.products WHERE id = v_offer.product_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'emails', '[]'::jsonb, 'error', 'Producto no encontrado');
  END IF;

  SELECT COALESCE(jsonb_agg(email), '[]'::jsonb) INTO v_emails
  FROM public.profiles
  WHERE email IS NOT NULL AND email <> '';

  IF jsonb_array_length(v_emails) = 0 THEN
    RETURN jsonb_build_object('ok', false, 'emails', v_emails, 'error', 'No hay clientes con correo registrado');
  END IF;

  PERFORM net.http_post(
    url := 'https://api.resend.com/emails',
    headers := jsonb_build_object(
      'Authorization', 'Bearer re_ZMktz9SM_3XDuYU3Y7xpRHa1Uz4iZ5Pse',
      'Content-Type', 'application/json'
    ),
    body := jsonb_build_object(
      'from', 'DeliciasExpress <onboarding@resend.dev>',
      'to', v_emails,
      'subject', '🔥 ¡Oferta Relámpago! ' || v_product.name || ' con ' || v_offer.discount_percentage || '% de descuento',
      'html', '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;text-align:center">
        <h1 style="color:#dc2626">🔥 ¡OFERTA RELÁMPAGO!</h1>
        <p style="font-size:20px">' || v_product.name || ' con <strong>' || v_offer.discount_percentage || '% de descuento</strong></p>
        <p>Válido hasta: <strong>' || to_char(v_offer.ends_at AT TIME ZONE ''America/Bogota'', ''HH24:MI'') || '</strong> horas (hora de Colombia)</p>
        <a href="https://delicias-express-seven.vercel.app" style="display:inline-block;background:#dc2626;color:#fff;padding:14px 28px;border-radius:8px;text-decoration:none;font-size:16px">🚀 ¡Quiero pedirlo ya!</a>
        <p style="color:#888;font-size:12px;margin-top:24px">DeliciasExpress · Te enviamos este correo porque estás registrado en nuestra tienda.</p>
      </div>'
    )
  );

  RETURN jsonb_build_object('ok', true, 'emails', v_emails, 'error', NULL);
END;
$$;
